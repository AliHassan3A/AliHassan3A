import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

export function usePageTransition(onComplete: () => void) {
  const location = useLocation();

  useEffect(() => {
    const sequence = async () => {
      // Initial delay for animation
      await new Promise(resolve => setTimeout(resolve, 1000));
      onComplete();
    };
    sequence();
  }, [location.pathname, onComplete]);
}