import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { HomePage } from './pages/HomePage';
import { AIPage } from './pages/AIPage';
import { LoadingScreen } from './components/LoadingScreen';
import { PageTransition } from './components/PageTransition';

function App() {
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  return (
    <>
      {isInitialLoading ? (
        <LoadingScreen onLoadingComplete={() => setIsInitialLoading(false)} />
      ) : (
        <Router>
          <div className="min-h-screen bg-gradient-to-b from-blue-900 via-blue-800 to-purple-900">
            <Navbar />
            <Routes>
              <Route 
                path="/" 
                element={
                  <PageTransition>
                    <HomePage />
                  </PageTransition>
                } 
              />
              <Route 
                path="/ai" 
                element={
                  <PageTransition>
                    <AIPage />
                  </PageTransition>
                } 
              />
            </Routes>
          </div>
        </Router>
      )}
    </>
  );
}

export default App;