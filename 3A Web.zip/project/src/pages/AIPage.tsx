import React from 'react';
import { Bot, Sparkles, Image, MessageSquare } from 'lucide-react';

export function AIPage() {
  const features = [
    {
      icon: <MessageSquare className="h-8 w-8 text-purple-400" />,
      title: "GPT-3.5 Powered Chat",
      description: "Experience intelligent conversations with our advanced language model, capable of understanding context and providing helpful responses."
    },
    {
      icon: <Image className="h-8 w-8 text-blue-400" />,
      title: "DALL-E 3 Integration",
      description: "Generate stunning, creative images from text descriptions using the latest DALL-E 3 technology."
    },
    {
      icon: <Bot className="h-8 w-8 text-purple-400" />,
      title: "Discord Integration",
      description: "Seamlessly integrate AI capabilities into your Discord server with simple commands and intuitive interfaces."
    },
    {
      icon: <Sparkles className="h-8 w-8 text-blue-400" />,
      title: "Smart Automation",
      description: "Automate routine tasks and enhance server engagement with intelligent bot features and responses."
    }
  ];

  return (
    <div className="min-h-screen pt-32 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 relative">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full bg-gradient-to-r from-blue-600/20 to-purple-600/20 blur-3xl rounded-[100px] -z-10" />
          
          <Bot className="h-16 w-16 mx-auto text-purple-400 mb-6" />
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Meet <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">3A AI</span> Bot
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Your intelligent Discord companion powered by GPT-3.5 and DALL-E 3
          </p>
          
          <a
            href="https://discord.com/oauth2/authorize?client_id=1285787887945912420&permissions=67584&scope=bot"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-full hover:opacity-90 transition-all"
          >
            <Bot className="mr-2" size={20} />
            Add to Discord
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white/5 backdrop-blur-lg rounded-3xl p-8 hover:bg-white/10 transition-all">
              <div className="bg-gradient-to-r from-blue-900 to-purple-900 rounded-2xl p-4 w-fit mb-6">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-semibold text-white mb-4">{feature.title}</h3>
              <p className="text-gray-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}