import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Hero } from '../components/Hero';
import { ContactForm } from '../components/ContactForm';
import { Footer } from '../components/Footer';
import { Separator } from '../components/Separator';

export function HomePage() {
  const location = useLocation();

  useEffect(() => {
    if (location.state?.scrollToContact) {
      setTimeout(() => {
        document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
      }, 1000);
    }
  }, [location.state]);

  return (
    <>
      <Hero />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ContactForm />
        <Separator />
        <Footer />
      </div>
    </>
  );
}