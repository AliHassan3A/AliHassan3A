import React from 'react';
import { Code2, Laptop, Smartphone } from 'lucide-react';
import { FeatureCard } from './FeatureCard';

export function Features() {
  const features = [
    {
      icon: <Laptop className="w-12 h-12 mx-auto text-purple-400" />,
      title: "Expert Web Development",
      description: "Power up your vision with our expert web developers, creating stunning and scalable solutions powered by 3A"
    },
    {
      icon: <Smartphone className="w-12 h-12 mx-auto text-blue-400" />,
      title: "App Development",
      description: "Transform your mobile vision into reality with cutting-edge app development powered by 3A"
    },
    {
      icon: <Code2 className="w-12 h-12 mx-auto text-purple-400" />,
      title: "Custom Solutions",
      description: "Tailored development solutions that perfectly align with your business goals and requirements"
    }
  ];

  return (
    <div className="mt-24 md:mt-48 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-12 px-4 md:px-0">
      {features.map((feature, index) => (
        <FeatureCard key={index} {...feature} />
      ))}
    </div>
  );
}