import React from 'react';
import { Code2 } from 'lucide-react';

export function Logo() {
  return (
    <div className="relative">
      <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg blur opacity-30 group-hover:opacity-100 transition duration-1000"></div>
      <div className="relative bg-gradient-to-r from-blue-900 to-purple-900 rounded-lg p-2 flex items-center">
        <Code2 className="h-6 w-6 text-purple-400" />
        <span className="ml-2 text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">3A</span>
      </div>
    </div>
  );
}