import React from 'react';
import { Mail } from 'lucide-react';

export function HeroHeader() {
  const scrollToContact = () => {
    document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="text-center relative px-4 md:px-0">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-full bg-gradient-to-r from-blue-600/20 to-purple-600/20 blur-3xl rounded-[100px] -z-10" />
      
      <h2 className="text-lg md:text-xl text-purple-300 font-medium mb-4">
        Power it with 3A
      </h2>
      <h1 className="text-3xl md:text-6xl font-bold text-white mb-6 leading-tight">
        Turn Your <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Visions</span> Into Reality
      </h1>
      <p className="text-lg md:text-xl text-gray-300 mb-12 max-w-2xl mx-auto px-4 md:px-0">
        Transforming ideas into powerful web and mobile experiences that drive growth and innovation.
      </p>
      
      <div className="flex justify-center">
        <button 
          onClick={scrollToContact}
          className="group bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 md:px-8 py-3 rounded-full hover:opacity-90 transition-all flex items-center justify-center"
        >
          <Mail className="mr-2 group-hover:scale-110 transition-transform" size={20} />
          Contact Us
        </button>
      </div>
    </div>
  );
}