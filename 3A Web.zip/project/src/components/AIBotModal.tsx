import React, { useState } from 'react';
import { Bot, X, Check, AlertCircle } from 'lucide-react';

interface AIBotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AIBotModal({ isOpen, onClose }: AIBotModalProps) {
  const [agreed, setAgreed] = useState(false);

  const handleAgree = () => {
    if (agreed) {
      window.open('https://discord.com/oauth2/authorize?client_id=1285787887945912420&permissions=67584&scope=bot', '_blank');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-blue-900 to-purple-900 rounded-3xl max-w-2xl w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-400 hover:text-white transition-colors"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="flex items-center justify-center mb-6">
          <Bot className="h-12 w-12 text-purple-400 mr-3" />
          <h2 className="text-3xl font-bold text-white">3A AI Bot</h2>
        </div>

        <div className="space-y-6 mb-8">
          <div className="bg-white/5 rounded-xl p-4">
            <h3 className="text-xl font-semibold text-white mb-2">Powerful AI Features</h3>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-400 mr-2" />
                Advanced GPT-3.5 powered chat capabilities
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-400 mr-2" />
                DALL-E 3 image generation
              </li>
              <li className="flex items-center">
                <Check className="h-5 w-5 text-green-400 mr-2" />
                Seamless Discord integration
              </li>
            </ul>
          </div>

          <div className="bg-white/5 rounded-xl p-4">
            <h3 className="text-xl font-semibold text-white mb-2">Rules & Guidelines</h3>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-400 mr-2 flex-shrink-0 mt-1" />
                Use the bot responsibly and in accordance with Discord's Terms of Service
              </li>
              <li className="flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-400 mr-2 flex-shrink-0 mt-1" />
                Do not use the bot for generating harmful or inappropriate content
              </li>
              <li className="flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-400 mr-2 flex-shrink-0 mt-1" />
                Respect rate limits and fair usage policies
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-center space-y-4">
          <label className="flex items-center space-x-2 text-white cursor-pointer">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="w-5 h-5 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
            />
            <span>I agree to follow the rules and guidelines</span>
          </label>

          <button
            onClick={handleAgree}
            disabled={!agreed}
            className={`w-full py-3 px-6 rounded-xl font-semibold transition-all ${
              agreed
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:opacity-90'
                : 'bg-gray-600 text-gray-400 cursor-not-allowed'
            }`}
          >
            Add to Discord
          </button>
        </div>
      </div>
    </div>
  );
}