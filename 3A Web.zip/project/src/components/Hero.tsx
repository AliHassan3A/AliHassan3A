import React from 'react';
import { HeroHeader } from './HeroHeader';
import { Features } from './Features';

export function Hero() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-blue-900 via-blue-800 to-purple-900 pt-32">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-10"></div>
      </div>
      
      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
        <HeroHeader />
        <Features />
      </div>
    </div>
  );
}