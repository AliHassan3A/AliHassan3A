import React, { useEffect, useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Bot } from 'lucide-react';
import { Logo } from './Logo';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleContactClick = () => {
    if (location.pathname === '/') {
      document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate('/', { state: { scrollToContact: true } });
    }
  };

  return (
    <div className="fixed top-0 left-0 right-0 z-50 px-2 md:px-4 py-4">
      <nav className={`max-w-5xl mx-auto transition-all duration-300 rounded-2xl ${
        isScrolled ? 'bg-white/5 backdrop-blur-md shadow-lg' : ''
      }`}>
        <div className="px-3 md:px-6 py-3">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center">
              <Logo />
            </Link>
            
            <div className="flex items-center space-x-2 md:space-x-4">
              <Link
                to="/ai"
                className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-3 md:px-6 py-2 rounded-full hover:opacity-90 transition-opacity flex items-center text-sm md:text-base"
              >
                <Bot className="mr-1 md:mr-2 h-4 w-4 md:h-5 md:w-5" />
                3A AI
              </Link>
              <button 
                onClick={handleContactClick}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-3 md:px-6 py-2 rounded-full hover:opacity-90 transition-opacity text-sm md:text-base"
              >
                Contact Us
              </button>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
}