import React, { useEffect, useState } from 'react';
import { Logo } from './Logo';

interface LoadingScreenProps {
  onLoadingComplete: () => void;
}

export function LoadingScreen({ onLoadingComplete }: LoadingScreenProps) {
  const [animationState, setAnimationState] = useState<'initial' | 'center' | 'final'>('initial');

  useEffect(() => {
    // Start the animation sequence
    const sequence = async () => {
      // Wait for initial render
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Move to center
      setAnimationState('center');
      
      // Wait at center
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Move back to position
      setAnimationState('final');
      
      // Complete the animation
      await new Promise(resolve => setTimeout(resolve, 400));
      onLoadingComplete();
    };

    sequence();
  }, [onLoadingComplete]);

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-blue-900 via-blue-800 to-purple-900 flex items-center justify-center z-50">
      <div
        className={`transform transition-all duration-500 ease-in-out ${
          animationState === 'initial' 
            ? 'scale-100 translate-x-0 translate-y-0 opacity-0'
            : animationState === 'center'
            ? 'scale-150 translate-x-0 translate-y-0 opacity-100'
            : 'scale-100 translate-x-0 translate-y-0 opacity-0'
        }`}
      >
        <Logo />
      </div>
    </div>
  );
}