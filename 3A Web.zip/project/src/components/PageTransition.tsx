import React, { useState } from 'react';
import { usePageTransition } from '../utils/transitions';
import { LoadingScreen } from './LoadingScreen';

interface PageTransitionProps {
  children: React.ReactNode;
}

export function PageTransition({ children }: PageTransitionProps) {
  const [isTransitioning, setIsTransitioning] = useState(true);
  
  usePageTransition(() => setIsTransitioning(false));

  if (isTransitioning) {
    return <LoadingScreen onLoadingComplete={() => setIsTransitioning(false)} />;
  }

  return <>{children}</>;
}