import React from 'react';
import { Mail } from 'lucide-react';

export function ContactForm() {
  return (
    <div id="contact-form" className="py-24 relative">
      <div className="absolute inset-0">
        <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-1/2 bg-gradient-to-r from-blue-600/20 to-purple-600/20 blur-3xl rounded-[100px] -z-10" />
      </div>
      
      <div className="relative">
        <h2 className="text-4xl font-bold text-center text-white mb-4">Get in Touch</h2>
        <div className="flex flex-col items-center justify-center space-y-4 mb-12">
          <p className="text-xl text-gray-300 text-center max-w-2xl">
            Ready to transform your vision into reality? Contact us today and let's create something amazing together.
          </p>
          <a 
            href="mailto:3a.studios.3a@gmail.com"
            className="flex items-center text-purple-400 hover:text-purple-300 transition-colors text-xl"
          >
            <Mail className="w-6 h-6 mr-2" />
            3a.studios.3a@gmail.com
          </a>
        </div>
      </div>
    </div>
  );
}