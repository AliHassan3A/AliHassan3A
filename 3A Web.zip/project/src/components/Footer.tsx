import React from 'react';

export function Footer() {
  return (
    <footer className="py-12 relative">
      <div className="absolute inset-0">
        <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-1/2 bg-gradient-to-r from-purple-600/10 to-blue-600/10 blur-3xl rounded-[100px] -z-10" />
      </div>
      
      <div className="relative text-center space-y-6">
        <p className="text-2xl bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent font-medium">
          Power your visions with 3A
        </p>
        <div className="space-y-2">
          <p className="text-gray-300">All rights reserved to 3A, 2024</p>
          <p className="text-purple-300 font-medium">3A Founder: Ali Hassan Ahmed</p>
        </div>
      </div>
    </footer>
  );
}