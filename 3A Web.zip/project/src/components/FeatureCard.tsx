import React, { useEffect, useRef, useState } from 'react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export function FeatureCard({ icon, title, description }: FeatureCardProps) {
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      {
        threshold: 0.1,
      }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => {
      if (cardRef.current) {
        observer.unobserve(cardRef.current);
      }
    };
  }, []);

  return (
    <div
      ref={cardRef}
      className={`group bg-white bg-opacity-5 backdrop-blur-lg rounded-3xl p-8 hover:bg-opacity-10 transition-all relative overflow-hidden transform ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
      }`}
      style={{ transitionDuration: '700ms' }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
      <div className="relative">
        <div className="bg-gradient-to-r from-blue-900 to-purple-900 rounded-2xl p-4 w-fit mx-auto mb-4 transform group-hover:scale-110 transition-transform duration-300">
          {icon}
        </div>
        <h3 className="text-2xl font-semibold text-white mt-4 mb-3 transform group-hover:translate-y-[-2px] transition-transform duration-300">{title}</h3>
        <p className="text-gray-300 text-lg leading-relaxed transform group-hover:translate-y-[-2px] transition-transform duration-300">{description}</p>
      </div>
    </div>
  );
}